#ifndef HEADER_Item

#define HEADER_Item

typedef char *Item; 

#endif
