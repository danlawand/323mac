#include "item.h"

#define bool int

void queueInit();

void queueInsert(Item item);

Item queueRemove();

bool queueEmpty();

int queueSize();

void queueFree();

void printqueue();
