/*\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__

  AO PREENCHER ESSE CABEÇALHO COM O MEU NOME E O MEU NÚMERO USP,
  DECLARO QUE SOU O ÚNICO AUTOR E RESPONSÁVEL POR ESSE PROGRAMA.
  TODAS AS PARTES ORIGINAIS DESSE EXERCÍCIO PROGRAMA (EP) FORAM
  DESENVOLVIDAS E IMPLEMENTADAS POR MIM SEGUINDO AS INSTRUÇÕES DESSE EP
  E QUE PORTANTO NÃO CONSTITUEM PLÁGIO. DECLARO TAMBÉM QUE SOU RESPONSÁVEL
  POR TODAS AS CÓPIAS DESSE PROGRAMA E QUE EU NÃO DISTRIBUI OU FACILITEI A
  SUA DISTRIBUIÇÃO. ESTOU CIENTE QUE OS CASOS DE PLÁGIO SÃO PUNIDOS COM
  REPROVAÇÃO DIRETA NA DISCIPLINA.

  Nome: DANIEL ANGELO ESTEVES LAWAND
  NUSP: 10297693

  ABB.c

\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__*/
#include "ABB.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

static NodeAbb r;
static int n = 0;
FILE *pFile;

static void *mallocSafe(size_t nbytes);

static void inOrdem(NodeAbb);
static NodeAbb putTree(NodeAbb, Keyabb);
static NodeAbb getTree(NodeAbb, Keyabb);
static int compare(Keyabb, Keyabb);

NodeAbb newNodeABB (Keyabb key, Valueabb val) {
  NodeAbb p;
  p = mallocSafe(sizeof(*p));
  p->key = key;
  p->val = val;
  p->left = NULL;
  p->right = NULL;
  n++;
  return p;
}

Valueabb getABB (Keyabb key) {
  NodeAbb x;
  x = getTree(r, key);
  if (x == NULL) return 0;
  return x->val;
}

void putABB (Keyabb key){
  r = putTree(r, key);
}

void printABB() {
  inOrdem(r);
}

int sizeABB() {
  return n;
}
/* Implementação das rotinas auxiliares */
static void inOrdem(NodeAbb r) {
  if (r != NULL) {
    inOrdem(r->left);
    printf("%s %d\n", r->key, r->val);
    inOrdem(r->right);
  }
}

static NodeAbb putTree(NodeAbb x, Keyabb key) {
  int cmp;
  if (x == NULL)
    return newNodeABB(key, 1);
  cmp = compare(key, x->key);
  if (cmp < 0)
    x->left = putTree(x->left, key);
  else if (cmp > 0)
    x->right = putTree(x->right, key);
  else x->val++;
  return x;
}


static NodeAbb getTree(NodeAbb x, Keyabb key) {
  int cmp;
  if (x == NULL) return NULL;
  cmp = compare(key, x->key);
  if (cmp < 0)
    return getTree(x->left, key);
  if (cmp > 0)
    return getTree(x->right, key);
  return x;
}

static int compare(Keyabb k1, Keyabb k2) {
  return strcmp(k1, k2);
}

static void *mallocSafe(size_t nbytes) {
  void *p = malloc(nbytes);

  if (p == NULL) {
    printf("Erro: alocação de memória falhou no módulo Node.");
    exit(0);
  }
  return p;
}
