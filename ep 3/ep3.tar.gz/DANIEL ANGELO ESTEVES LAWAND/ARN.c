/*\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__

  AO PREENCHER ESSE CABEÇALHO COM O MEU NOME E O MEU NÚMERO USP,
  DECLARO QUE SOU O ÚNICO AUTOR E RESPONSÁVEL POR ESSE PROGRAMA.
  TODAS AS PARTES ORIGINAIS DESSE EXERCÍCIO PROGRAMA (EP) FORAM
  DESENVOLVIDAS E IMPLEMENTADAS POR MIM SEGUINDO AS INSTRUÇÕES DESSE EP
  E QUE PORTANTO NÃO CONSTITUEM PLÁGIO. DECLARO TAMBÉM QUE SOU RESPONSÁVEL
  POR TODAS AS CÓPIAS DESSE PROGRAMA E QUE EU NÃO DISTRIBUI OU FACILITEI A
  SUA DISTRIBUIÇÃO. ESTOU CIENTE QUE OS CASOS DE PLÁGIO SÃO PUNIDOS COM
  REPROVAÇÃO DIRETA NA DISCIPLINA.

  Nome: DANIEL ANGELO ESTEVES LAWAND
  NUSP: 10297693

  ARN.c

\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__*/

#include "ARN.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

#define RED 1
#define BLACK 0

static NodeARN r;
static int quantidade = 0;
FILE *pFile;

static void *mallocSafe(size_t nbytes);
static bool isRed(NodeARN);
static NodeARN getTree(NodeARN, Keyarn);
static NodeARN rotateLeft(NodeARN);
static NodeARN rotateRight(NodeARN);
static void flipColors(NodeARN);
static NodeARN putTree(NodeARN, Keyarn);
static NodeARN balance(NodeARN);
static void inOrdem(NodeARN);
static int sizeRamo(NodeARN);
static int compare(Keyarn, Keyarn);

NodeARN newNodeARN (Keyarn key, Valuearn val, int n, bool color) {
  NodeARN p = mallocSafe(sizeof(*p));
  quantidade++;
  p->key = key;
  p->n = n;
  p->left = NULL;
  p->val = val;
  p->color = color;
  p->right = NULL;
  return p;
}

Valuearn getARN(Keyarn key) {
  NodeARN x = getTree(r, key);
  if (x == NULL) return 0;
  return x->val;
}

void putARN(Keyarn key) {
  r = putTree(r, key);
  r->color = BLACK;
}

void printARN() {
  inOrdem(r);
}

int sizeARN() {
  return quantidade;
}
/* Implementação das rotinas auxiliares */
static void inOrdem(NodeARN r) {
  if (r != NULL) {
    inOrdem(r->left);
    printf("%s %d\n", r->key, r->val);
    inOrdem(r->right);
  }
}

static NodeARN balance(NodeARN h) {
  if (isRed(h->right) && !isRed(h->left)) {
    h = rotateLeft(h);
  }
  if (isRed(h->left) && isRed(h->left->left)) {
    h = rotateRight(h);
  }
  if (isRed(h->left) && isRed(h->right)){
    flipColors(h);
  }
  return h;
}


static NodeARN putTree(NodeARN h, Keyarn key) {
  int cmp;
  if (h == NULL) {
    return newNodeARN(key, 1, 1, RED);
  }
  cmp = compare(key, h->key);
  if (cmp < 0) {
    h->left = putTree(h->left, key);
  } else if (cmp > 0) {
    h->right = putTree(h->right, key);
  } else h->val = h->val + 1;
  h = balance(h);
  return h;
}

static void flipColors(NodeARN h) {
  h->color = RED;
  h->left->color  = BLACK;
  h->right->color = BLACK;
}

static int sizeRamo(NodeARN h) {
  if (h == NULL) return 0;
  return h->n;
}

static NodeARN rotateRight(NodeARN h) {
  NodeARN x = h->left;
  h->left = x->right;
  x->right = h;
  x->color = h->color;
  h->color = RED;
  x->n = h->n;
  h->n = 1 + sizeRamo(h->left) + sizeRamo(h->right);
  return x;
}


static NodeARN rotateLeft (NodeARN h) {
  NodeARN x = h->right;
  h->right = x->left;
  x->left = h;
  x->color = h->color;
  h->color = RED;
  x->n = h->n;
  h->n = 1 + sizeRamo(h->left) + sizeRamo(h->right);
  return x;
}

static NodeARN getTree(NodeARN x, Keyarn key) {
  int cmp;
  if (x == NULL) return NULL;
  cmp = compare(key, x->key);
  if (cmp < 0) return getTree(x->left, key);
  else if (cmp > 0) return getTree(x->right, key);
  else return x;
}

static bool isRed(NodeARN x) {
  if (x == NULL) return 0;
  return x->color == RED;
}

static int compare(Keyarn k1, Keyarn k2) {
  return strcmp(k1, k2);
}

static void *mallocSafe(size_t nbytes) {
  void *p = malloc(nbytes);

  if (p == NULL) {
    printf("Erro: alocação de memória falhou no módulo Node.");
    exit(0);
  }
  return p;
}
