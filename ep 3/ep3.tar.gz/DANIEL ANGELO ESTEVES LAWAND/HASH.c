/*\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__

  AO PREENCHER ESSE CABEÇALHO COM O MEU NOME E O MEU NÚMERO USP,
  DECLARO QUE SOU O ÚNICO AUTOR E RESPONSÁVEL POR ESSE PROGRAMA.
  TODAS AS PARTES ORIGINAIS DESSE EXERCÍCIO PROGRAMA (EP) FORAM
  DESENVOLVIDAS E IMPLEMENTADAS POR MIM SEGUINDO AS INSTRUÇÕES DESSE EP
  E QUE PORTANTO NÃO CONSTITUEM PLÁGIO. DECLARO TAMBÉM QUE SOU RESPONSÁVEL
  POR TODAS AS CÓPIAS DESSE PROGRAMA E QUE EU NÃO DISTRIBUI OU FACILITEI A
  SUA DISTRIBUIÇÃO. ESTOU CIENTE QUE OS CASOS DE PLÁGIO SÃO PUNIDOS COM
  REPROVAÇÃO DIRETA NA DISCIPLINA.

  Nome: DANIEL ANGELO ESTEVES LAWAND
  NUSP: 10297693

  HASH.c

\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__*/

#include "HASH.h"
#include "stdlib.h"
#include "stdio.h"
#include <string.h>


static int n;/* número de chaves */
static int m;/* tam. da tabela de hash */

/* vetor da tabela de símbolos */
static Item **st;

static void put(int, Keyh, Valueh);
static Valueh get(int, Keyh);
static void resize(int);
static void insertST(Keyh , Valueh);
static void freeST(Item**, int);
static int hash(Keyh);
static void *mallocSafe(size_t nbytes);
static int compare(Keyh, Keyh);


void SeparateChainingHashSTInit(int size) {
  int h;
  n = 0;
  m = size;
  st = mallocSafe(m * sizeof(*st));
  for (h = 0; h < m; h++)
    st[h] = NULL;
}

Valueh getST(Keyh key) {
  int h = hash(key);
  return get(h, key);
}

void putST(Keyh key) {
  int h;
  if (n >= 10*m) resize(2*m);
  h = hash(key);
  put(h, key, 1);
}

int sizeHASH() {
  return n;
}

static void put(int h, Keyh key, Valueh val) {
  /*Implementar aqui a lista encadeada*/
  Item *p, *q, *item;
  if (st[h] ==  NULL) {
    item = mallocSafe(sizeof(*item));
    item->key = key;
    item->val = val;
    item->next = NULL;
    st[h] = item;
    n++;
    return;
  }
  for (p = st[h]; p != NULL; p = p->next) {
    q = p;
    if (compare(p->key, key) == 0) {
      p->val = p->val + 1;
      return;
    }
  }
  item = mallocSafe(sizeof(*item));
  item->key = key;
  item->val = val;
  item->next = NULL;
  q->next = item;
  n++;
}

static Valueh get(int h, Keyh key) {
  Item *p;
  for (p = st[h]; p != NULL ; p = p->next) {
    if (compare(p->key, key) == 0) {
      return p->val;
    }
  }
  return 0;
}

static void resize(int size) {
  Item *p, **t = st;
  int h, aux = m;
  m = size;
  st = mallocSafe(size*sizeof(*st));
  for (h = 0; h < m; h++) st[h] = NULL;
  for (h = 0; h < aux; h++) {
    for (p = t[h]; p != NULL; p = p->next) {
      insertST(p->key, p->val);
    }
  }
  freeST(t, aux); /*Precisa implementar isso*/
}

static void insertST(Keyh key, Valueh val) {
  int h = hash(key);
  Item *p, *item;
  if (st[h] == NULL) {
    item = mallocSafe(sizeof(*item));
    item->key = key;
    item->val = val;
    item->next = NULL;
    st[h] = item;
    return;
  }
  for (p = st[h]; p->next != NULL ; p = p->next);
  item = mallocSafe(sizeof(*item));
  item->key = key;
  item->val = val;
  item->next = NULL;
  p->next = item;
}

static void freeST(Item** t, int aux) {
  Item *q, *p;
  int h;
  for (h = 0; h < aux; h++) {
    for (p = t[h]; p != NULL; p = p->next) {
      q = p;
      free(p);
      p = q;
    }
  }
  free(t);
}

static int hashCode(Keyh key) {
  int i, h = 0;
  for (i = 0; i < strlen(key); i++)
    h = (31 * h + key[i]) % m;
  return h;
}

static int hash(Keyh key) {
  return hashCode(key) % m;
}

static int compare(Keyh k1, Keyh k2) {
  return strcmp(k1, k2);
}

static void *mallocSafe(size_t nbytes) {
  void *p = malloc(nbytes);

  if (p == NULL) {
    printf("Erro: alocação de memória falhou no módulo Node.");
    exit(0);
  }
  return p;
}
