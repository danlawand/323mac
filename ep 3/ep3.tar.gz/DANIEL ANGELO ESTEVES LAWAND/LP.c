/*\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__

  AO PREENCHER ESSE CABEÇALHO COM O MEU NOME E O MEU NÚMERO USP,
  DECLARO QUE SOU O ÚNICO AUTOR E RESPONSÁVEL POR ESSE PROGRAMA.
  TODAS AS PARTES ORIGINAIS DESSE EXERCÍCIO PROGRAMA (EP) FORAM
  DESENVOLVIDAS E IMPLEMENTADAS POR MIM SEGUINDO AS INSTRUÇÕES DESSE EP
  E QUE PORTANTO NÃO CONSTITUEM PLÁGIO. DECLARO TAMBÉM QUE SOU RESPONSÁVEL
  POR TODAS AS CÓPIAS DESSE PROGRAMA E QUE EU NÃO DISTRIBUI OU FACILITEI A
  SUA DISTRIBUIÇÃO. ESTOU CIENTE QUE OS CASOS DE PLÁGIO SÃO PUNIDOS COM
  REPROVAÇÃO DIRETA NA DISCIPLINA.

  Nome: DANIEL ANGELO ESTEVES LAWAND
  NUSP: 10297693

  LP.c

\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__*/

#include "LP.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

static int n;
static int m;
static Keyl   *keys;
static Valuel *vals;


static void resizeLP(int);
static void insertLP(Keyl, Valuel);
static int hashCode(Keyl);
static int hash(Keyl);
static int compare(Keyl, Keyl);
static void *mallocSafe(size_t nbytes);


void LinearProbingHashSTInit(int cap) {
  int h;
  m = cap;
  keys = mallocSafe(m * sizeof(Keyl));
  vals = mallocSafe(m * sizeof(Valuel));
  for (h = 0; h < m; h++) {
    keys[h] = NULL;
    vals[h] = 0;
  }
  n = 0;
}

Valuel getLP(Keyl key) {
  int h;
  for (h=hash(key); keys[h]!=NULL; h=(h+1)%m)
    if (compare(keys[h], key) == 0)
      return vals[h];
  return 0;
}

void putLP(Keyl key) {
  int h;
  if (n >= m/2) resizeLP(2*m);
  for (h=hash(key); keys[h]!=NULL; h=(h+1)%m)
    if (compare(keys[h], key) == 0) {
      vals[h] = vals[h] + 1;
      return;
    }
  keys[h] = key;
  vals[h] = 0;
  n++;
}

int sizeLP(){
  return n;
}

static void resizeLP(int cap) {
  Keyl *k = keys;
  Valuel *v = vals;
  int h, aux = m;
  m = cap;
  keys = mallocSafe(m * sizeof(Keyl));
  vals = mallocSafe(m * sizeof(Valuel));
  for (h = 0; h < m; h++) {
    keys[h] = NULL;
    vals[h] = 0;
  }
  for (h = 0; h < aux; h++) {
    if (k[h] != NULL)
      insertLP(k[h], v[h]);
  }
  free(k);
  free(v);
}

static void insertLP(Keyl key, Valuel val) {
  int h;
  for (h = hash(key); keys[h] != NULL; h=(h+1)%m);
  keys[h] = key;
  vals[h] = val;
}


static int hashCode(Keyl key) {
  int i, h = 0;
  for (i = 0; i < strlen(key); i++)
    h = (31 * h + key[i]) % m;
  return h;
}

static int hash(Keyl key) {
  return hashCode(key) % m;
}

static int compare(Keyl k1, Keyl k2) {
  return strcmp(k1, k2);
}

static void *mallocSafe(size_t nbytes) {
  void *p = malloc(nbytes);

  if (p == NULL) {
    printf("Erro: alocação de memória falhou no módulo Node.");
    exit(0);
  }
  return p;
}
