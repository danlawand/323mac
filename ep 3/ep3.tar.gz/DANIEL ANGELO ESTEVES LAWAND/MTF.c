/*\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__

  AO PREENCHER ESSE CABEÇALHO COM O MEU NOME E O MEU NÚMERO USP,
  DECLARO QUE SOU O ÚNICO AUTOR E RESPONSÁVEL POR ESSE PROGRAMA.
  TODAS AS PARTES ORIGINAIS DESSE EXERCÍCIO PROGRAMA (EP) FORAM
  DESENVOLVIDAS E IMPLEMENTADAS POR MIM SEGUINDO AS INSTRUÇÕES DESSE EP
  E QUE PORTANTO NÃO CONSTITUEM PLÁGIO. DECLARO TAMBÉM QUE SOU RESPONSÁVEL
  POR TODAS AS CÓPIAS DESSE PROGRAMA E QUE EU NÃO DISTRIBUI OU FACILITEI A
  SUA DISTRIBUIÇÃO. ESTOU CIENTE QUE OS CASOS DE PLÁGIO SÃO PUNIDOS COM
  REPROVAÇÃO DIRETA NA DISCIPLINA.

  Nome: DANIEL ANGELO ESTEVES LAWAND
  NUSP: 10297693

  MTF.c

\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__*/

#include "MTF.h"
#include "stdlib.h"
#include "stdio.h"
#include <string.h>


static int n;/* número de chaves */
static int m;/* tam. da tabela de hash */

/* vetor da tabela de símbolos */
static MTF **st;

static void put(int, Keym, Valuem);
static MTF* get(int, Keym);
static void resize(int);
static void insertST(Keym , Valuem);
static void freeST(MTF**, int);
static int hash(Keym);
static void *mallocSafe(size_t nbytes);
static int compare(Keym, Keym);


void MTFInit(int size) {
  int h;
  n = 0;
  m = size;
  st = mallocSafe(m * sizeof(*st));
  for (h = 0; h < m; h++)
    st[h] = NULL;
}

Valuem getMTF(Keym key) {
  int h = hash(key);
  return get(h, key)->val;
}

void putMTF(Keym key) {
  int h;
  if (n >= 10*m) resize(2*m);
  h = hash(key);
  put(h, key, 1);
}

int sizeMTF() {
  return n;
}

static void put(int h, Keym key, Valuem val) {
  MTF *p, *q, *item;
  if (st[h] ==  NULL) {
    item = mallocSafe(sizeof(*item));
    item->key = key;
    item->val = val;
    item->next = NULL;
    st[h] = item;
    n++;
    return;
  }
  q = st[h]; /* Caso o seja o primeiro*/
  for (p = st[h]; p != NULL; p = p->next) {
    if (compare(p->key, key) == 0) {
      if (p == st[h]) {
        p->val = p->val + 1;
        return;
      }
      q->next = p->next;
      p->next = st[h];
      st[h] = p;
      return;
    }
    q = p;
  }
  item = mallocSafe(sizeof(*item));
  item->key = key;
  item->val = val;
  item->next = st[h];
  st[h] = item;
  n++;
}

static MTF* get(int h, Keym key) {
  MTF *p, *q;
  for (p = st[h]; p != NULL ; p = p->next) {
    if (compare(p->key, key) == 0) {
      return q;
    }
    q = p;
  }
  return NULL;
}

static void resize(int size) {
  MTF *p, **t = st;
  int h, aux = m;
  m = size;
  st = mallocSafe(size*sizeof(*st));
  for (h = 0; h < m; h++) st[h] = NULL;
  for (h = 0; h < aux; h++) {
    for (p = t[h]; p != NULL; p = p->next) {
      insertST(p->key, p->val);
    }
  }
  freeST(t, aux); /*Precisa implementar isso*/
}

static void insertST(Keym key, Valuem val) {
  int h = hash(key);
  MTF *p, *item;
  if (st[h] == NULL) {
    item = mallocSafe(sizeof(*item));
    item->key = key;
    item->val = val;
    item->next = NULL;
    st[h] = item;
    return;
  }
  for (p = st[h]; p->next != NULL ; p = p->next);
  item = mallocSafe(sizeof(*item));
  item->key = key;
  item->val = val;
  item->next = NULL;
  p->next = item;
}

static void freeST(MTF** t, int aux) {
  MTF *q, *p;
  int h;
  for (h = 0; h < aux; h++) {
    for (p = t[h]; p != NULL; p = p->next) {
      q = p;
      free(p);
      p = q;
    }
  }
  free(t);
}

static int hashCode(Keym key) {
  int h = 0;
  int i;
  for (i = 0; i < strlen(key); i++)
    h = (31 * h + key[i]) % m;
  return h;
}

static int hash(Keym key) {
  return hashCode(key) % m;
}

static int compare(Keym k1, Keym k2) {
  return strcmp(k1, k2);
}

static void *mallocSafe(size_t nbytes) {
  void *p = malloc(nbytes);

  if (p == NULL) {
    printf("Erro: alocação de memória falhou no módulo Node.");
    exit(0);
  }
  return p;
}
