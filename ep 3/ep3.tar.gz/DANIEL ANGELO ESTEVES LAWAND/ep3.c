/*\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__

  AO PREENCHER ESSE CABEÇALHO COM O MEU NOME E O MEU NÚMERO USP,
  DECLARO QUE SOU O ÚNICO AUTOR E RESPONSÁVEL POR ESSE PROGRAMA.
  TODAS AS PARTES ORIGINAIS DESSE EXERCÍCIO PROGRAMA (EP) FORAM
  DESENVOLVIDAS E IMPLEMENTADAS POR MIM SEGUINDO AS INSTRUÇÕES DESSE EP
  E QUE PORTANTO NÃO CONSTITUEM PLÁGIO. DECLARO TAMBÉM QUE SOU RESPONSÁVEL
  POR TODAS AS CÓPIAS DESSE PROGRAMA E QUE EU NÃO DISTRIBUI OU FACILITEI A
  SUA DISTRIBUIÇÃO. ESTOU CIENTE QUE OS CASOS DE PLÁGIO SÃO PUNIDOS COM
  REPROVAÇÃO DIRETA NA DISCIPLINA.

  Nome: DANIEL ANGELO ESTEVES LAWAND
  NUSP: 10297693

  ep3.c

\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__*/

#include "time.h"
#include "stdio.h"
#include "stdlib.h"
#include <string.h>
#include "ABB.h"
#include "ARN.h"
#include "HASH.h"
#include "MTF.h"
#include "LP.h"
#include "tries.h"

static char* buffer;

void insereNaED(long lSize, int flag) {
  long i = 1, k = 0, j = 0;
  char **word, c;
  int tamanho = 0, n = 0;
  word = malloc(lSize*sizeof(char *));
  while (i < lSize) {
    c = buffer[i];
    if (i < lSize && ((c >= 65 && c <= 90) || (c >= 97 && c <= 122))) {
      while (i < lSize && ((c >= 65 && c <= 90) || (c >= 97 && c <= 122)) ){
        if (c >= 'A' && c <= 'Z') {
          buffer[i] = (char) ((int)buffer[i] + 32);
        }
        tamanho++;
        i++;
        c = buffer[i];
      }
      if (tamanho > 0) {
        word[n] = malloc((tamanho)*sizeof(char));
        word[n][tamanho] = '\0';
        for (j = i-tamanho, k = 0; j < i && k < tamanho; j++, k++) {
          word[n][k] = buffer[j];
        }
        if (flag == 1) putABB(word[n]);
        else if (flag == 2) putARN(word[n]);
        else if (flag == 3) putST(word[n]);
        else if (flag == 4) putMTF(word[n]);
        else if (flag == 5) putLP(word[n]);
        else putTrie(word[n]);
        n++;
        tamanho = 0;
      }
    } else {
      i++;
    }
  }
  free(word);
}


int main(int argc, char *argv[]) {
  FILE * pFile;
  long lSize;
  char *filename;
  size_t result;
  clock_t ini, fim;
  double total = 0;

  if (argc < 2) {
    printf("Número inválido de argumentos\n");
    exit(1);
  }

  filename = argv[1];
  pFile = fopen ( filename , "r" );
  if (pFile == NULL) {
    fputs ("File error",stderr);
    exit (1);
  }

  /* obtain file size:*/
  fseek (pFile , 0 , SEEK_END);
  lSize = ftell (pFile);
  rewind (pFile);

  /* allocate memory to contain the whole file:*/
  buffer = (char*) malloc (sizeof(char)*lSize);
  if (buffer == NULL) {fputs ("Memory error",stderr); exit (2);}

  /* copy the file into the buffer:*/
  result = fread (buffer,1,lSize,pFile);
  if (result != lSize) {fputs ("Reading error",stderr); exit (3);}
  /* the whole file is now loaded in the memory buffer. */

  SeparateChainingHashSTInit(1);
  MTFInit(1);
  LinearProbingHashSTInit(1);

  ini = clock();
  insereNaED(lSize, 1); /*ABB*/
  fim = clock();
  total = (double)(fim - ini) / CLOCKS_PER_SEC;
  printf("N. de palavras na ABB                     %d -- %f segundos\n", sizeABB(), total);

  ini = clock();
  insereNaED(lSize, 2); /*ARN*/
  fim = clock();
  total = (double)(fim - ini) / CLOCKS_PER_SEC;
  printf("N. de palavras na ARN                     %d -- %f segundos\n", sizeARN(), total);

  ini = clock();
  insereNaED(lSize, 3); /*HASH*/
  fim = clock();
  total = (double)(fim - ini) / CLOCKS_PER_SEC;
  printf("N. de palavras no Hash com Encadeamento   %d -- %f segundos\n", sizeHASH(), total);

  ini = clock();
  insereNaED(lSize, 4); /*HASH MTF*/
  fim = clock();
  total = (double)(fim - ini) / CLOCKS_PER_SEC;
  printf("N. de palavras no Hash com MTF            %d -- %f segundos\n", sizeMTF(), total);

  ini = clock();
  insereNaED(lSize, 5); /*Linear Probing*/
  fim = clock();
  total = (double)(fim - ini) / CLOCKS_PER_SEC;
  printf("N. de palavras no Hash com Linear Probing %d -- %f segundos\n", sizeLP(), total);

  ini = clock();
  insereNaED(lSize, 6); /*TRIE*/
  fim = clock();
  total = (double)(fim - ini) / CLOCKS_PER_SEC;
  printf("N. de palavras na TRIE                    %d -- %f segundos\n", sizeTRIE(), total);

  fclose (pFile);
  free (buffer);
  return 0;
}
