/*\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__

  AO PREENCHER ESSE CABEÇALHO COM O MEU NOME E O MEU NÚMERO USP,
  DECLARO QUE SOU O ÚNICO AUTOR E RESPONSÁVEL POR ESSE PROGRAMA.
  TODAS AS PARTES ORIGINAIS DESSE EXERCÍCIO PROGRAMA (EP) FORAM
  DESENVOLVIDAS E IMPLEMENTADAS POR MIM SEGUINDO AS INSTRUÇÕES DESSE EP
  E QUE PORTANTO NÃO CONSTITUEM PLÁGIO. DECLARO TAMBÉM QUE SOU RESPONSÁVEL
  POR TODAS AS CÓPIAS DESSE PROGRAMA E QUE EU NÃO DISTRIBUI OU FACILITEI A
  SUA DISTRIBUIÇÃO. ESTOU CIENTE QUE OS CASOS DE PLÁGIO SÃO PUNIDOS COM
  REPROVAÇÃO DIRETA NA DISCIPLINA.

  Nome: DANIEL ANGELO ESTEVES LAWAND
  NUSP: 10297693

  tries.c

\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__*/

#include "tries.h"
#include "stdlib.h"
#include "stdio.h"
#include "string.h"

static int n;
static Node r;

static Node getT(Node x, Key key, int d);
static Node putT(Node x, Key key, Value val, int d);
static void *mallocSafe(size_t nbytes);

Node newNode(char c) {
  Node no = mallocSafe(sizeof(*no));
  no->c = c;
  no->val = 0;
  no->left = NULL;
  no->mid = NULL;
  no->right = NULL;
  return no;
}

int sizeTRIE() {
  return n;
}

Value getTrie(Key key) {
  Node x = getT(r, key, 0);
  if (x == NULL) return 0;
  return x->val;
}
static Node getT(Node x, Key key, int d) {
  char c = key[d];
  if (x == NULL) return NULL;
  if (c < x->c) return getT(x->left, key, d);
  if (c > x->c) return getT(x->right, key, d);
  if (d < strlen(key)-1) return getT(x->mid, key, d+1);
  return x;
}

void putTrie(Key key) {
  r = putT(r, key, 1, 0);
}

static Node putT(Node x, Key key, Value val, int d) {
  char c = key[d];
  if (x == NULL) x = newNode(c); /*Criar newNode*/
  if (c < x->c) x->left = putT(x->left, key, val, d);
  else if (c > x->c) x->right = putT(x->right, key, val, d);
  else if (d < strlen(key)-1) x->mid = putT(x->mid, key, val, d+1);
  else  {
    x->val = x->val + 1;
    if (x->val == 1) n++;
  }
  return x;
}

static void *mallocSafe(size_t nbytes) {
  void *p = malloc(nbytes);

  if (p == NULL) {
    printf("Erro: alocação de memória falhou no módulo Node.");
    exit(0);
  }
  return p;
}
