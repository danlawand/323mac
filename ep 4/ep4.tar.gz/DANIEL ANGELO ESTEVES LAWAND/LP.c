/*\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__

  AO PREENCHER ESSE CABEÇALHO COM O MEU NOME E O MEU NÚMERO USP,
  DECLARO QUE SOU O ÚNICO AUTOR E RESPONSÁVEL POR ESSE PROGRAMA.
  TODAS AS PARTES ORIGINAIS DESSE EXERCÍCIO PROGRAMA (EP) FORAM
  DESENVOLVIDAS E IMPLEMENTADAS POR MIM SEGUINDO AS INSTRUÇÕES DESSE EP
  E QUE PORTANTO NÃO CONSTITUEM PLÁGIO. DECLARO TAMBÉM QUE SOU RESPONSÁVEL
  POR TODAS AS CÓPIAS DESSE PROGRAMA E QUE EU NÃO DISTRIBUI OU FACILITEI A
  SUA DISTRIBUIÇÃO. ESTOU CIENTE QUE OS CASOS DE PLÁGIO SÃO PUNIDOS COM
  REPROVAÇÃO DIRETA NA DISCIPLINA.

  Nome: DANIEL ANGELO ESTEVES LAWAND
  NUSP: 10297693

  LP.c

\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__*/

#include "LP.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

LP st;

static void resizeLP(int);
static void insertLP(Key, Value);
static int hashCode(Key);
static int hash(Key);
static int compare(Key, Key);
static void *mallocSafe(size_t nbytes);


LP LinearProbingHashSTInit(int cap) {
  int h;
  st = mallocSafe(sizeof(*st));
  st->m = cap;
  st->keys = mallocSafe(st->m * sizeof(Key));
  st->vals = mallocSafe(st->m * sizeof(Value));
  for (h = 0; h < st->m; h++) {
    st->keys[h] = NULL;
    st->vals[h] = NULL;
  }
  st->n = 0;
  return st;
}

Value getLP(Key key) {
  int h;
  for (h=hash(key); st->keys[h]!=NULL; h=(h+1)%st->m)
    if (compare(st->keys[h], key) == 0)
      return st->vals[h];
  return NULL;
}

int putLP(Key key) {
  int h;
  Vertice novoVertice;
  Node cabeca;
  if (st->n >= st->m/2) resizeLP(2*st->m);
  for (h=hash(key); st->keys[h]!=NULL; h=(h+1)%st->m)
    if (compare(st->keys[h], key) == 0) return -1;

  novoVertice = mallocSafe(sizeof(*novoVertice));
  cabeca = mallocSafe(sizeof(*cabeca));
  cabeca->next = NULL;
  st->keys[h] = key;
  st->vals[h] = novoVertice;
  st->vals[h]->palavra = key;
  st->vals[h]->adj = cabeca;
  st->vals[h]->dg = 0;
  st->vals[h]->index = h;
  st->n++;
  return h;
}

int sizeLP(){
  return st->n;
}

static void resizeLP(int cap) {
  Key *k = st->keys;
  Value *v = st->vals;
  int h, aux = st->m;
  st->m = cap;
  st->keys = mallocSafe(st->m * sizeof(Key));
  st->vals = mallocSafe(st->m * sizeof(Value));
  for (h = 0; h < st->m; h++) {
    st->keys[h] = NULL;
    st->vals[h] = NULL;
  }
  for (h = 0; h < aux; h++) {
    if (k[h] != NULL)
      insertLP(k[h], v[h]);
  }
  free(k);
  free(v);
}

static void insertLP(Key key, Value val) {
  int h;
  for (h = hash(key); st->keys[h] != NULL; h=(h+1)%st->m);
  st->keys[h] = key;
  st->vals[h] = val;
  st->vals[h]->index = h;
}

static int hashCode(Key key) {
  int i, h = 0;
  for (i = 0; i < strlen(key); i++)
    h = (31 * h + key[i]) % st->m;
  return h;
}

static int hash(Key key) {
  return hashCode(key) % st->m;
}

static int compare(Key k1, Key k2) {
  return strcmp(k1, k2);
}

static void *mallocSafe(size_t nbytes) {
  void *p = malloc(nbytes);

  if (p == NULL) {
    printf("Erro: alocação de memória falhou no módulo Node.");
    exit(0);
  }
  return p;
}
