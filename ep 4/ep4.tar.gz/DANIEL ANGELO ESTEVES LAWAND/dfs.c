/*\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__

  AO PREENCHER ESSE CABEÇALHO COM O MEU NOME E O MEU NÚMERO USP,
  DECLARO QUE SOU O ÚNICO AUTOR E RESPONSÁVEL POR ESSE PROGRAMA.
  TODAS AS PARTES ORIGINAIS DESSE EXERCÍCIO PROGRAMA (EP) FORAM
  DESENVOLVIDAS E IMPLEMENTADAS POR MIM SEGUINDO AS INSTRUÇÕES DESSE EP
  E QUE PORTANTO NÃO CONSTITUEM PLÁGIO. DECLARO TAMBÉM QUE SOU RESPONSÁVEL
  POR TODAS AS CÓPIAS DESSE PROGRAMA E QUE EU NÃO DISTRIBUI OU FACILITEI A
  SUA DISTRIBUIÇÃO. ESTOU CIENTE QUE OS CASOS DE PLÁGIO SÃO PUNIDOS COM
  REPROVAÇÃO DIRETA NA DISCIPLINA.

  Nome: DANIEL ANGELO ESTEVES LAWAND
  NUSP: 10297693

  dfs.c

\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__*/

#include"graph.h"
#include "LP.h"
#include "dfs.h"
#include <string.h>
#include <stdio.h>
#include "stdlib.h"

static dfsPaths DFSpathsInit(LP);
static void dfs(LP, int, dfsPaths);
static void *mallocSafe(size_t nbytes);


static dfsPaths DFSpathsInit(LP G) {
  int v;
  dfsPaths T = mallocSafe(sizeof(struct dfspaths));
  T->marked = mallocSafe(G->m * sizeof(bool));
  T->edgeTo = mallocSafe(G->m * sizeof(int));
  T->count = 0;
  T->tamanhoMax = 0;
  T->id = mallocSafe(G->m * sizeof(int));
  T->tamComp = mallocSafe(G->m * sizeof(int));
  for (v = 0; v < G->m; v++) {
    T->marked[v] = 0;
    T->edgeTo[v] = -1;
    T->tamComp[v] = 0;
  }
  return T;
}

dfsPaths DFSpaths(LP G) {
  int i;
  dfsPaths T = DFSpathsInit(G);
  for (i = 0; i < G->m; i++) {
    if (G->keys[i] == NULL || T->marked[i]) continue;
    T->edgeTo[i] = i;
    dfs(G, i, T);
    T->count++;
  }
  return T;
}

static void dfs(LP G, int v, dfsPaths T){
  /*Nó w que percorre a lista de adjacência desse vértice*/
  Node w;

  /*v é o índice do vértice em T que está chamando a dfs*/
  T->marked[v] = 1;
  T->id[v] = T->count;
  T->tamComp[T->count]++;
  if (T->tamanhoMax < T->tamComp[T->count]) T->tamanhoMax =T->tamComp[T->count];
  for (w = G->vals[v]->adj->next; w != NULL; w = w->next) {
    if (!T->marked[w->vertex_st->index]) {
      T->edgeTo[w->vertex_st->index] = v;
      dfs(G, w->vertex_st->index, T);
    }
  }
}


static void *mallocSafe(size_t nbytes) {
  void *p = malloc(nbytes);

  if (p == NULL) {
    printf("Erro: alocação de memória falhou no módulo Node.");
    exit(0);
  }
  return p;
}
