/*
 \__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__

  AO PREENCHER ESSE CABEÇALHO COM O MEU NOME E O MEU NÚMERO USP,
  DECLARO QUE SOU O ÚNICO AUTOR E RESPONSÁVEL POR ESSE PROGRAMA.
  TODAS AS PARTES ORIGINAIS DESSE EXERCÍCIO-PROGRAMA (EP) FORAM
  DESENVOLVIDAS E IMPLEMENTADAS POR MIM SEGUINDO AS INSTRUÇÕES DESSE EP
  E QUE PORTANTO NÃO CONSTITUEM PLÁGIO. DECLARO TAMBÉM QUE SOU RESPONSÁVEL
  POR TODAS AS CÓPIAS DESSE PROGRAMA E QUE EU NÃO DISTRIBUI OU FACILITEI A
  SUA DISTRIBUIÇÃO. ESTOU CIENTE QUE OS CASOS DE PLÁGIO SÃO PUNIDOS COM
  REPROVAÇÃO DIRETA NA DISCIPLINA.

  Nome: DANIEL ANGELO ESTEVES LAWAND
  NUSP: 10297693

  ep4.c

  Referências: Com exceção das rotinas fornecidas no esqueleto e em sala
  de aula, caso você tenha utilizado alguma referência, liste-as abaixo
  para que o seu programa não seja considerada plágio.
  Exemplo:

  - função mallocSafe copiada de:

       http://www.ime.usp.br/~pf/algoritmos/aulas/aloca.html

 \__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__
*/

#include "graph.h"
#include "LP.h"
#include "dfs.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

#define TAMANHO_MAX 200
#define SAIR         "sair"
#define INSERE       "insere"
#define INFO         "info"
#define VIZINHO      "vizinho"
#define ARTICULACAOC "articulacao"
#define TAMC         "tamC"
#define PROMPT  printf(">>> ");

/*
 * int alfabeto(char a)
 *
 * Retorna 1 se o caractere a sera
 * considerado como parte de uma palavra
 * e 0 caso contrario
 *
 */
int alfabeto(char a){
    if(a == '-' || a == '\'' || a == '_' || a == '@')
        return 1;

    return (a >= 'a' && a <= 'z') || (a >= 'A' && a <= 'Z');
}

/*
 * char lower(char a)
 *
 * Transforma a em uma letra minuscula
 *
 */
char lower(char a){
    if(a >= 'A' && a <= 'Z')
        return a - 'A' + 'a';

    return a;
}

/*
 * char * alocaPalavra(char * buffer)
 *
 * Trata a string salva em buffer e aloca
 * memoria para guarda-la.
 *
 * Retorna o endereco alocado
 *
 */
char * alocaPalavra(char ** buffer){
    char * palavra = NULL;
    int i = 0, j = 0, size = 0;

    for(i = 0; (*buffer)[i] != '\0' && !alfabeto((*buffer)[i]); i++);

    (*buffer) = (*buffer) + i;

    /* checa o tamanho da palavra */
    for(i = 0, size = 0; (*buffer)[i] != '\0' && alfabeto((*buffer)[i]); i++, size++);

    if(size > 0){
        palavra = malloc((size + 1)*sizeof(char));

        /* salva a palavra */
        for(i = 0, j = 0; (*buffer)[i] != '\0' && alfabeto((*buffer)[i]); i++)
            if(alfabeto((*buffer)[i]))
                palavra[j++] = lower((*buffer)[i]);

        palavra[size] = '\0';
        (*buffer) = (*buffer) + size;
    }


    return palavra;
}

/*
 * void mostreUso()
 *
 * Mostra como invocar o ep4 corretamente
 *
 */
void mostreUso(){
    printf("Para executar forneça o parâmetro k e o texto a ser lido.\n");
    printf("Exemplo:\n");
    printf("./ep4 k texto.txt\n");
}

/*
 * void menu()
 *
 * Exibe o menu de opcoes
 *
 */
void menu(){
    printf("\n----------------------------MENU---------------------------\n");
    printf("%s - recebe duas string a e b e devolve se são vizinhas\n", VIZINHO);
    printf("%s - insere a palavra digitada no grafo\n", INSERE);
    printf("%s - devolve se o vertice da string a e' uma articulacao\n", ARTICULACAOC);
    printf("%s - devolve o tamanho da componente da palavra digitada\n", TAMC);
    printf("%s - devolve as informacoes exigidas no enunciado\n", INFO);
    printf("%s - sai do programa\n", SAIR);
    printf("-----------------------------------------------------------\n");
    PROMPT;
}

int main(int argc, char * argv[]){
    int k, artic;
    char buffer[TAMANHO_MAX];
    int total = 0;
    char * copia;
    char * nome, * palavra, * b;
    double start, end, ellapsed;
    FILE * arquivo = NULL;
    int v, a, grau_min, grau_max;
    double grau_media, density;

    if(argc != 3){
        mostreUso();
        return 0;
    }

    k = atoi(argv[1]);
    nome = argv[2];
    arquivo = fopen(nome, "r");

    if(arquivo == NULL) {
        printf("Ocorreu um erro, arquivo não pôde ser aberto.\n");
        return 0;
    }

    inicializa(k);
    while(fscanf(arquivo, "%s", buffer) && !feof(arquivo)){ /* le do arquivo */
        copia = buffer;

        while ((palavra = alocaPalavra(&copia)) != NULL){
            total++;
            insere(palavra);
        }
    }

    fclose(arquivo);

    menu();
    scanf("%s", buffer);
    copia = buffer;
    while (strcmp(buffer, SAIR))
    {
        if(!strcmp(buffer, INSERE)){
            scanf("%s", buffer);
            copia = buffer;
            palavra = alocaPalavra(&copia);

            if(palavra != NULL){
                /* insere no grafo */
                start = clock();
                printf("%d arestas adicionadas\n", insere(palavra));
                end = clock();
                ellapsed = (end - start)/CLOCKS_PER_SEC;
                printf("Operação levou %.6lf segundos\n", ellapsed);

                start = clock();
                printf("%d Grau da Palavra adicionadas\n", grau(palavra));
                end = clock();
                ellapsed = (end - start)/CLOCKS_PER_SEC;
                printf("Operação levou %.6lf segundos\n", ellapsed);
            }
        }
        else if(!strcmp(buffer, VIZINHO)){
            scanf("%s", buffer);
            copia = buffer;
            palavra = alocaPalavra(&copia);
            scanf("%s", buffer);
            copia = buffer;
            b = alocaPalavra(&copia);

            if(palavra != NULL && b != NULL){
                printf("%s e %s ", palavra, b);

                if(!vizinho(palavra, b))
                    printf("não ");

                printf("são vizinhas\n");
            }

            if(palavra != NULL)
                free(palavra);

            if(b != NULL)
                free(b);

            palavra = b = NULL;
        }
        else if(!strcmp(buffer, TAMC)){
            scanf("%s", buffer);
            copia = buffer;
            palavra = alocaPalavra(&copia);

            if(palavra != NULL){
                start = clock();
                printf("A palavra %s está em uma componente conexa de tamanho %d\n",
                palavra, tamanhoComponente(palavra));
                end = clock();
                ellapsed = (end - start)/CLOCKS_PER_SEC;
                printf("Operação levou %.6lf segundos\n", ellapsed);

                free(palavra);
            }
        }
        else if(!strcmp(buffer, ARTICULACAOC)){
            scanf("%s", buffer);
            copia = buffer;
            palavra = alocaPalavra(&copia);

            if(palavra != NULL){
                printf("O vértice da palavra %s ", palavra);
                start = clock();
                artic = articulacao(palavra);
                end = clock();
                ellapsed = (end - start)/CLOCKS_PER_SEC;
                if(artic != 1)
                    printf("não ");
                printf("é de articulação\n");
                printf("Operação levou %.6lf segundos\n", ellapsed);

                free(palavra);
            }
        }
        else if(!strcmp(buffer, INFO)){
            start = clock();
            v = vertices(TOTAL);
            a = arestas();
            end = clock();
            ellapsed = (end - start)/CLOCKS_PER_SEC;
            printf("O grafo possui %d vertices e %d arestas\n", v, a);
            printf("Operação levou %.6lf segundos\n\n", ellapsed);

            start = clock();
            grau_min = grauMin();
            grau_max = grauMax();
            grau_media = grauMedia();
            end = clock();
            ellapsed = (end - start)/CLOCKS_PER_SEC;
            printf("O Grau Mínimo: %d \nGrau Máximo: %d\nMédia de Grau %lf\n", grau_min, grau_max, grau_media);
            printf("Operação levou %.6lf segundos\n\n", ellapsed);

            start = clock();
            density = densidade();
            end = clock();
            ellapsed = (end - start)/CLOCKS_PER_SEC;
            printf("A Densidade do grafo é: %lf\n", density);
            printf("Operação levou %.6lf segundos\n\n", ellapsed);

            start = clock();
            printf("A Quantidade de Componentes Conexas do grafo é: %d\n", componentes());
            end = clock();
            ellapsed = (end - start)/CLOCKS_PER_SEC;
            printf("Operação levou %.6lf segundos\n\n", ellapsed);

            start = clock();
            printf("O Tamanho Mínimo de Componente Conexa do grafo é: %d\n", tamanhoMinComponente());
            end = clock();
            ellapsed = (end - start)/CLOCKS_PER_SEC;
            printf("Operação levou %.6lf segundos\n\n", ellapsed);

            start = clock();
            printf("O Tamanho Máximo de Componente Conexa do grafo é: %d\n", tamanhoMaxComponente());
            end = clock();
            ellapsed = (end - start)/CLOCKS_PER_SEC;
            printf("Operação levou %.6lf segundos\n\n", ellapsed);

            start = clock();
            printf("O Tamanho Médio de Componente Conexa do grafo é: %lf\n", tamanhoMedioComponente());
            end = clock();
            ellapsed = (end - start)/CLOCKS_PER_SEC;
            printf("Operação levou %.6lf segundos\n\n", ellapsed);
        }

        menu();
        scanf("%s", buffer);
        copia = buffer;
    }

    return 0;
}
