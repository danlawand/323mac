/*
 \__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__

  AO PREENCHER ESSE CABEÇALHO COM O MEU NOME E O MEU NÚMERO USP,
  DECLARO QUE SOU O ÚNICO AUTOR E RESPONSÁVEL POR ESSE PROGRAMA.
  TODAS AS PARTES ORIGINAIS DESSE EXERCÍCIO-PROGRAMA (EP) FORAM
  DESENVOLVIDAS E IMPLEMENTADAS POR MIM SEGUINDO AS INSTRUÇÕES DESSE EP
  E QUE PORTANTO NÃO CONSTITUEM PLÁGIO. DECLARO TAMBÉM QUE SOU RESPONSÁVEL
  POR TODAS AS CÓPIAS DESSE PROGRAMA E QUE EU NÃO DISTRIBUI OU FACILITEI A
  SUA DISTRIBUIÇÃO. ESTOU CIENTE QUE OS CASOS DE PLÁGIO SÃO PUNIDOS COM
  REPROVAÇÃO DIRETA NA DISCIPLINA.

  Nome: DANIEL ANGELO ESTEVES LAWAND
  NUSP: 10297693

  graph.c

  Referências: Com exceção das rotinas fornecidas no esqueleto e em sala
  de aula, caso você tenha utilizado alguma referência, liste-as abaixo
  para que o seu programa não seja considerada plágio.
  Exemplo:

  - função mallocSafe copiada de:

       http://www.ime.usp.br/~pf/algoritmos/aulas/aloca.html

 \__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__
*/

#include"graph.h"
#include "LP.h"
#include "dfs.h"
#include <string.h>
#include <stdio.h>
#include "stdlib.h"

static int V;
static int A;
static int K;
static int dgrau[2];

static void *mallocSafe(size_t nbytes);
LP st;
void inicializa(int k){
  st = LinearProbingHashSTInit(1);
  K = k;
  V = 0;
  A = 0;
  /*Conta o Grau Máximo*/
  dgrau[0] = -1;
  /*Somatório dos Graus de cada Vértice*/
  dgrau[1] = 0;
}


int vizinho(char * a, char * b){
  /* Verifica as 'regrinhas'*/
  int x, y, i, j, maximo, diferente, troca;
  char a1, b1, a2, b2;
  x = strlen(a);
  y = strlen(b);
  if (x > y) maximo = x;
  else maximo = y;
  troca = 0;
  diferente = 0;
  /* Nenhum caso |x - y| >= 2*/
  if (x - y >= 2 || x - y <= -2) return 0;

  /*Remoção*/
  if (x - y == 1 || x-y == -1) {
    for (i = 0, j = 0; i < x && j < y && diferente < 2; i++, j++) {
      a1 = a[i];
      b1 = b[j];
      if (a1 == b1) continue;
      diferente++;
      if (x == maximo) j--;
      else i--;
    }
    if (diferente == 1) return 1;
  }
  diferente = 0;
  if (x - y == 0) {
    /*Substituição*/
    for (i = 0, j = 0; i < x && j < y && diferente < 2; i++, j++) {
      a1 = a[i];
      b1 = b[j];
      if (a1 == b1) continue;
      diferente++;
    }
    if (diferente == 1) return 1;
    diferente = 0;

    /*Troca de Letras*/
    for (i = 0; i < x && diferente < 3; i++) {
      a1 = a[i];
      b1 = b[i];
      if (a1 == b1) continue;
      diferente++;
      if (diferente == 1) {
        a2 = a1;
        b2 = b1;
      } else {
        if (a1 == b2 && b1 == a2) {
         troca = 1;
       }
      }
    }
    if (troca == 1 && diferente == 2) {
      return 1;
    }
  }
  return 0;
}

int insere(char * palavra){
  int i, h;
  Node no, no1;
  if (strlen(palavra) < K) return -1;

  /*Insere palavra na LP*/
  h = putLP(palavra);
  if (h != -1) {
    V = V + 1;
    if (V == 1) {
      dgrau[0] = 0;
    }
    /* Se palavra não estava na ST
    * Verifica todas as palavras na ST
    * e diz quais são vizinhos*/
    for (i = 0; i < st->m; i++) {
      if (st->keys[i] == NULL) continue;
      if (strcmp(st->keys[i], palavra) == 0) continue;
      if (vizinho(palavra, st->keys[i])) {

        no = mallocSafe(sizeof(*no));
        no->next = st->vals[h]->adj->next;
        st->vals[h]->adj->next = no;
        no->vertex_st = st->vals[i];
        st->vals[h]->dg = st->vals[h]->dg + 1;

        no1 = mallocSafe(sizeof(*no1));
        no1->next = st->vals[i]->adj->next;
        st->vals[i]->adj->next = no1;
        no1->vertex_st = st->vals[h];
        st->vals[i]->dg = st->vals[i]->dg + 1;

        /*Grau Máximo*/
        if (dgrau[0] < st->vals[i]->dg) dgrau[0] = st->vals[i]->dg;
        if (dgrau[0] < st->vals[h]->dg) dgrau[0] = st->vals[h]->dg;

        /*Somatório dos Graus*/
        dgrau[1] = dgrau[1] + 2;

        /*Quantidade de arestas*/
        A = A + 1;
      }
    }
    return 1;
  }
  return 0;
}

int vertices(int tipo){
    return V;
}

int arestas(){
    return A;
}

int grauMin() {
  int i, min_dg;
  min_dg = 2147483647;
  if (V == 0) return -1;
  if (V == 1) return 0;
  for (i = 0; i < st->m; i++) {
    if (st->keys[i] == NULL) continue;
    if (min_dg > st->vals[i]->dg) min_dg = st->vals[i]->dg;
    if (min_dg == 0) return min_dg;
  }
  return min_dg;
}

int grauMax() {
  if(dgrau[0] < 0) return -1;
  return dgrau[0];
}

double grauMedia() {
  double media;
  if (V == 0) return -1;
  media = (double)dgrau[1]/V;
  return media;
}

int grau(char * a){
  Value v = getLP(a);
  if (v == NULL) return -1;
  return v->dg;
}

double densidade(){
  double d;
  if (V <= 1) return 0;
  d = (double) (2 * A) / (double) (V*(V-1));
  return d;
}

int componentes(){
  dfsPaths T;
  T = DFSpaths(st);
  return T->count;
}

int articulacao(char * a){
    return -1;
}

int tamanhoComponente(char * a){
  Value v = getLP(a);
  dfsPaths T;
  if (v == NULL) return -1;
  T = DFSpaths(st);
  return T->tamComp[T->id[v->index]];
}

double tamanhoMedioComponente() {
  dfsPaths T;
  if (V == 0) return -1;
  T = DFSpaths(st);
  return (double) V / (double) T->count;
}

int tamanhoMaxComponente() {
  dfsPaths T;
  if (V == 0) return 1;
  T = DFSpaths(st);
  return T->tamanhoMax;
}

int tamanhoMinComponente() {
  int i, minComp;
  dfsPaths T;
  if (V == 0) return 1;
  T = DFSpaths(st);
  minComp = T->tamComp[0];
  for (i = 0; i < T->count; i++) {
    if (minComp > T->tamComp[i]) minComp = T->tamComp[i];
  }
  return minComp;
}

int distancia(char * a, char * b){
    return 0;
}

static void *mallocSafe(size_t nbytes) {
  void *p = malloc(nbytes);

  if (p == NULL) {
    printf("Erro: alocação de memória falhou no módulo Node.");
    exit(0);
  }
  return p;
}
