/*
 \__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__

  AO PREENCHER ESSE CABEÇALHO COM O MEU NOME E O MEU NÚMERO USP,
  DECLARO QUE SOU O ÚNICO AUTOR E RESPONSÁVEL POR ESSE PROGRAMA.
  TODAS AS PARTES ORIGINAIS DESSE EXERCÍCIO-PROGRAMA (EP) FORAM
  DESENVOLVIDAS E IMPLEMENTADAS POR MIM SEGUINDO AS INSTRUÇÕES DESSE EP
  E QUE PORTANTO NÃO CONSTITUEM PLÁGIO. DECLARO TAMBÉM QUE SOU RESPONSÁVEL
  POR TODAS AS CÓPIAS DESSE PROGRAMA E QUE EU NÃO DISTRIBUI OU FACILITEI A
  SUA DISTRIBUIÇÃO. ESTOU CIENTE QUE OS CASOS DE PLÁGIO SÃO PUNIDOS COM
  REPROVAÇÃO DIRETA NA DISCIPLINA.

  Nome: DANIEL ANGELO ESTEVES LAWAND
  NUSP: 10297693

  graph.h

  Referências: Com exceção das rotinas fornecidas no esqueleto e em sala
  de aula, caso você tenha utilizado alguma referência, liste-as abaixo
  para que o seu programa não seja considerada plágio.
  Exemplo:

  - função mallocSafe copiada de:

       http://www.ime.usp.br/~pf/algoritmos/aulas/aloca.html

 \__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__\__
*/

#ifndef _GRAPH_H
#define _GRAPH_H

#define TOTAL 0
#define ARTICULACAO 1

/*
 * void inicializa(int k);
 *
 * Inicializa um grafo com
 * parametro k.
 *
 */
void inicializa(int k);

/*
 * int vizinho(char * a, char * b);
 *
 * Recebe duas strings, a e b. Retorna 1
 * caso a e b sejam vizinhas e 0 caso
 * contrario.
 *
 */
int vizinho(char * a, char * b);

/*
 * int insere(char * palavra);
 *
 * Insere a string palavra no grafo e retorna
 * a quantidade de arestas que foram
 * adicionadas ao grafo.
 *
 * Retorna -1 caso a palavra nao tenha sido adicionada
 * (seja por ja estar no grafo ou por nao possuir
 * tamanho >= k)
 *
 */
int insere(char * palavra);

void buscaProfundidade();

/*
 * int vertices(int tipo)
 *
 * Se tipo == TOTAL retorna a quantidade
 * total de vertices do grafo
 *
 * Se tipo == ARTICULACAO retorna a quantidade
 * de vertices de articulacao do grafo
 *
 */
int vertices(int tipo);

/*
 * int arestas()
 *
 * Retorna a quantidade total de arestas do grafo
 *
 */
int arestas();


int grauMin();
int grauMax();
double grauMedia();

/*
 * int grau(char * a)
 *
 * Retorna o grau do vértice representado pela
 * string a
 *
 */
int grau(char * a);

/*
 * double densidade()
 *
 * Retorna a densidade do grafo
 *
 */
double densidade();

/*
 * int componentes()
 *
 * Retorna a quantidade de componentes conexas do grafo
 *
 */
int componentes();

/*
 * int articulacao(char * a)
 *
 * Retorna 1 se o vertice da string a
 * é de articulação, 0 se não é, -1
 * se a string a nao esteja no grafo
 *
 */
int articulacao(char * a);

/*
 * int tamanhoComponente(char * a)
 *
 * Retorna o tamanho da componente conexa
 * que contem o vertice da string a, -1
 * se a string a nao esteja no grafo
 *
 */
int tamanhoComponente(char * a);

double tamanhoMedioComponente();

int tamanhoMaxComponente();

int tamanhoMinComponente();

/*
 * int distancia(char * a, char * b)
 *
 * Retorna a quantidade de arestas
 * no caminho do vertice que contem
 * a string a para o vertice que contem
 * a string b
 *
 */
int distancia(char * a, char * b);

#endif
